# Local Plumbing Business Website

A modern, mobile-first, conversion-focused website for a local plumbing business. Built with **React**, **Vite**, **Tailwind CSS**, and **TypeScript**. Designed to generate phone calls, WhatsApp inquiries, emergency requests, and quote form submissions.

## Features

- Mobile-first responsive design
- Sticky navigation + persistent mobile bottom buttons (Call & WhatsApp)
- Click-to-call and WhatsApp pre-filled message integration
- SEO-ready meta tags, Open Graph, canonical URL, robots.txt, sitemap.xml
- LocalBusiness / Plumber structured data (JSON-LD)
- Accessible keyboard navigation and focus states
- Form validation with success/error states
- Environment-variable-driven business configuration
- Single-file Vite build for easy static hosting on Vercel

---

## Project Structure

```
.
├── index.html              # HTML entry point with SEO meta tags
├── package.json            # Dependencies and scripts
├── vite.config.ts          # Vite configuration
├── tsconfig.json           # TypeScript configuration
├── .env.example            # Example environment variables
├── README.md               # This file
├── public/
│   ├── robots.txt          # SEO robots directives
│   ├── sitemap.xml         # XML sitemap
│   └── og-image.jpg        # Open Graph image (replace with real image)
└── src/
    ├── main.tsx            # React entry point
    ├── App.tsx             # Main application component
    ├── index.css           # Global styles and Tailwind theme
    ├── vite-env.d.ts       # Vite env types
    ├── config/
    │   └── business.ts     # Central business configuration
    └── components/
        ├── Navbar.tsx
        ├── Hero.tsx
        ├── Trust.tsx
        ├── Services.tsx
        ├── EmergencyCTA.tsx
        ├── WhyChooseUs.tsx
        ├── HowItWorks.tsx
        ├── Reviews.tsx
        ├── ServiceAreas.tsx
        ├── FAQ.tsx
        ├── Contact.tsx
        ├── Footer.tsx
        ├── BottomButtons.tsx
        └── SchemaOrg.tsx
```

---

## Setup Instructions

### 1. Install Dependencies

```bash
npm install
```

### 2. Configure Environment Variables

Copy the example file and replace the placeholders:

```bash
cp .env.example .env
```

Edit `.env` with your real business details:

```env
VITE_BUSINESS_NAME=Your Plumbing Company
VITE_BUSINESS_TAGLINE=Reliable Plumbing Services When You Need Them
VITE_BUSINESS_DESCRIPTION=Professional plumbing services for homes and businesses in Your City, ST.
VITE_BUSINESS_LOCATION=Your City, ST
VITE_BUSINESS_ADDRESS=123 Main Street
VITE_BUSINESS_PHONE=+1 (555) 123-4567
VITE_BUSINESS_WHATSAPP=+15551234567
VITE_BUSINESS_EMAIL=info@yourplumbingco.com
VITE_WEBSITE_URL=https://yourplumbingco.vercel.app
VITE_BUSINESS_SERVICE_AREA=Your City and Surrounding Areas
```

> **Note:** All values starting with `VITE_` are exposed to the browser. Do not store secrets here.

### 3. Run Locally

```bash
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) in your browser.

### 4. Build for Production

```bash
npm run build
```

The static output is generated in `dist/`.

---

## GitHub Deployment Instructions

### 1. Create a GitHub Repository

1. Go to [https://github.com/new](https://github.com/new)
2. Enter a repository name, e.g. `your-plumbing-website`
3. Choose **Public** or **Private**
4. Click **Create repository**

### 2. Upload / Push the Project

If you already have the project folder locally:

```bash
cd your-plumbing-website
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/your-plumbing-website.git
git push -u origin main
```

Alternatively, use the GitHub web interface to upload files.

---

## Vercel Deployment Instructions

### 3. Import the Repository into Vercel

1. Go to [https://vercel.com/new](https://vercel.com/new)
2. Sign in with your GitHub account
3. Find and select your repository (`your-plumbing-website`)
4. Click **Import**

### 4. Configure Environment Variables

In the Vercel project configuration:

1. Expand **Environment Variables**
2. Add each variable from your `.env` file, e.g.:
   - `VITE_BUSINESS_NAME`
   - `VITE_BUSINESS_PHONE`
   - `VITE_BUSINESS_WHATSAPP`
   - `VITE_WEBSITE_URL`
   - etc.
3. Click **Deploy**

### 5. Deploy

Vercel will detect the Vite project automatically and run:

```bash
npm run build
```

Once the build succeeds, Vercel provides a live URL such as `https://your-plumbing-website.vercel.app`.

### 6. Connect a Custom Domain

1. In your Vercel dashboard, go to **Project Settings > Domains**
2. Click **Add**
3. Enter your domain (e.g. `www.yourplumbingco.com`)
4. Follow Vercel's DNS instructions
5. Update your DNS records at your domain registrar
6. Once verified, update `VITE_WEBSITE_URL`, `robots.txt`, and `sitemap.xml` with the new domain
7. Redeploy the project

### 7. Update the Website After Deployment

1. Make changes locally
2. Commit and push to GitHub:

```bash
git add .
git commit -m "Update business info and content"
git push origin main
```

3. Vercel will automatically rebuild and redeploy the site

---

## Placeholders to Replace

Before publishing, replace all bracketed placeholders with real information:

| Placeholder | Where to Update |
|-------------|-----------------|
| `[PLUMBER BUSINESS NAME]` | `.env` → `VITE_BUSINESS_NAME` |
| `[CITY, STATE]` | `.env` → `VITE_BUSINESS_LOCATION` |
| `[PHONE NUMBER]` | `.env` → `VITE_BUSINESS_PHONE` |
| `[WHATSAPP NUMBER]` | `.env` → `VITE_BUSINESS_WHATSAPP` |
| `[EMAIL]` | `.env` → `VITE_BUSINESS_EMAIL` |
| `[CITY + SURROUNDING AREAS]` | `.env` → `VITE_BUSINESS_SERVICE_AREA` |
| `[BUSINESS ADDRESS]` | `.env` → `VITE_BUSINESS_ADDRESS` |
| `[CITY]` / `[AREA 1]`–`[AREA 4]` | `src/components/ServiceAreas.tsx` |
| `[X]+` years, `[X,XXX]+` jobs, `[X.X/5]` rating | `src/components/Trust.tsx` |
| `[Customer Name]`, `[Location]` testimonials | `src/components/Reviews.tsx` |
| `[Plumbing service photo]` | Replace the Hero placeholder image or add an image to `public/` |
| `https://your-domain.vercel.app` | `.env`, `public/robots.txt`, `public/sitemap.xml`, `index.html` |
| Schema address fields | `src/components/SchemaOrg.tsx` |
| og-image.jpg | Replace `public/og-image.jpg` with a real branded image (1200×630 recommended) |

---

## SEO Checklist

- [ ] Unique title tag in `index.html`
- [ ] Meta description updated with real business info
- [ ] Canonical URL set in `index.html`
- [ ] Open Graph tags updated with real domain and image
- [ ] `robots.txt` updated with real domain
- [ ] `sitemap.xml` updated with real domain and lastmod date
- [ ] LocalBusiness / Plumber structured data populated
- [ ] Semantic HTML (header, main, section, article, nav, footer)
- [ ] Proper heading hierarchy (H1 → H2 → H3)
- [ ] Descriptive alt text on images
- [ ] Internal links with fragment anchors
- [ ] Click-to-call phone links
- [ ] WhatsApp direct message links

---

## Testing Checklist

- [ ] Website loads correctly on mobile (iPhone/Android)
- [ ] No horizontal scrolling on small screens
- [ ] Click-to-call button opens phone dialer
- [ ] WhatsApp button opens WhatsApp with pre-filled message
- [ ] Contact form validation works (try empty submit)
- [ ] Contact form success state displays
- [ ] All navigation links scroll to correct sections
- [ ] Mobile hamburger menu opens and closes
- [ ] Sticky bottom buttons visible on mobile
- [ ] Keyboard navigation works (Tab, Enter, Space)
- [ ] Focus indicators visible on interactive elements
- [ ] Page passes basic accessibility contrast check
- [ ] Build succeeds with `npm run build`
- [ ] `dist/index.html` loads without errors

---

## Form Backend Note

The contact form currently simulates a successful submission on the client side. To receive real submissions, connect it to a backend such as:

- [Formspree](https://formspree.io)
- [Netlify Forms](https://docs.netlify.com/forms/setup/)
- [Vercel Serverless Functions](https://vercel.com/docs/functions)
- Email service (e.g. SendGrid, Resend)

---

## License

This project is provided as a starter template. Customize it freely for your business.
