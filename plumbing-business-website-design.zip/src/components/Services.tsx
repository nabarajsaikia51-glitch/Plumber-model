import {
  AlertTriangle,
  Droplet,
  MoveRight,
  Trash2,
  Toilet,
  Flame,
  Bath,
  CookingPot,
  AlertOctagon,
  Droplets,
} from "lucide-react";
import { getTelLink, getWhatsAppUrl } from "@/config/business";

const services = [
  {
    title: "Emergency Plumbing",
    description:
      "Fast response for urgent plumbing issues such as burst pipes, severe leaks, and flooding. Available when you need help most.",
    icon: AlertTriangle,
  },
  {
    title: "Leak Repair",
    description:
      "Identify and repair water leaks before they cause costly damage to walls, floors, and foundations.",
    icon: Droplet,
  },
  {
    title: "Pipe Repair",
    description:
      "Repair or replace damaged, corroded, or frozen pipes to restore safe water flow throughout your property.",
    icon: MoveRight,
  },
  {
    title: "Drain Cleaning",
    description:
      "Clear clogged sinks, showers, and tubs with professional drain cleaning that gets water flowing again.",
    icon: Trash2,
  },
  {
    title: "Toilet Repair",
    description:
      "Fix running toilets, clogs, leaks, and flushing issues to keep your bathroom working properly.",
    icon: Toilet,
  },
  {
    title: "Faucet Repair",
    description:
      "Repair or replace dripping, leaking, or broken faucets in kitchens, bathrooms, and utility areas.",
    icon: Droplets,
  },
  {
    title: "Water Heater Service",
    description:
      "Installation, repair, and maintenance of tank and tankless water heaters for reliable hot water.",
    icon: Flame,
  },
  {
    title: "Bathroom Plumbing",
    description:
      "Full bathroom plumbing services including showers, bathtubs, sinks, toilets, and fixture upgrades.",
    icon: Bath,
  },
  {
    title: "Kitchen Plumbing",
    description:
      "Expert help with sinks, garbage disposals, dishwashers, ice makers, and kitchen fixture installations.",
    icon: CookingPot,
  },
  {
    title: "Sewer & Drain Problems",
    description:
      "Address slow drains, backups, and sewer line concerns with thorough inspection and repair options.",
    icon: AlertOctagon,
  },
];

export function Services() {
  return (
    <section id="services" className="section-padding bg-white">
      <div className="container-content mx-auto">
        <div className="mx-auto max-w-3xl text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-blue-600">Our Services</p>
          <h2 className="mt-2 text-3xl font-bold text-navy-900 sm:text-4xl">
            Plumbing Solutions for Every Need
          </h2>
          <p className="mt-4 text-lg text-navy-700">
            From urgent repairs to planned installations, we offer a full range of residential and
            commercial plumbing services.
          </p>
        </div>

        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service) => {
            const Icon = service.icon;
            return (
              <article
                key={service.title}
                className="group flex flex-col rounded-2xl border border-gray-100 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-lg"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-100 text-blue-600 transition group-hover:bg-blue-600 group-hover:text-white">
                  <Icon className="h-6 w-6" aria-hidden="true" />
                </div>
                <h3 className="mt-5 text-xl font-bold text-navy-900">{service.title}</h3>
                <p className="mt-2 flex-grow text-navy-700">{service.description}</p>
                <div className="mt-6 flex flex-col gap-2 sm:flex-row">
                  <a href={getTelLink()} className="btn-primary py-2.5 text-sm">
                    Call Now
                  </a>
                  <a
                    href={getWhatsAppUrl(`Hello, I'm interested in ${service.title}. My location is ______.` )}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-whatsapp py-2.5 text-sm"
                  >
                    WhatsApp
                  </a>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
