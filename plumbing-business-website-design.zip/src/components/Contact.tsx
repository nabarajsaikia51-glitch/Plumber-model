import { useState } from "react";
import { Phone, MessageCircle, Mail, Send, Loader2, CheckCircle2, AlertCircle } from "lucide-react";
import { BUSINESS, getTelLink, getWhatsAppUrl, getMailtoLink } from "@/config/business";

type FormStatus = "idle" | "submitting" | "success" | "error";

interface FormData {
  name: string;
  phone: string;
  email: string;
  service: string;
  message: string;
  preferredContact: "phone" | "whatsapp" | "email";
}

interface FormErrors {
  name?: string;
  phone?: string;
  email?: string;
  service?: string;
  message?: string;
}

const services = [
  "Emergency Plumbing",
  "Leak Repair",
  "Pipe Repair",
  "Drain Cleaning",
  "Toilet Repair",
  "Faucet Repair",
  "Water Heater Service",
  "Bathroom Plumbing",
  "Kitchen Plumbing",
  "Sewer/Drain Problems",
  "Other",
];

export function Contact() {
  const [formData, setFormData] = useState<FormData>({
    name: "",
    phone: "",
    email: "",
    service: "",
    message: "",
    preferredContact: "phone",
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [status, setStatus] = useState<FormStatus>("idle");

  function validate(): boolean {
    const newErrors: FormErrors = {};
    if (!formData.name.trim()) newErrors.name = "Please enter your name.";
    if (!formData.phone.trim()) {
      newErrors.phone = "Please enter your phone number.";
    } else if (!/^\+?[\d\s\-().]{7,}$/.test(formData.phone)) {
      newErrors.phone = "Please enter a valid phone number.";
    }
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Please enter a valid email address.";
    }
    if (!formData.service) newErrors.service = "Please select a service.";
    if (!formData.message.trim()) newErrors.message = "Please describe the plumbing issue.";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }

  function handleChange(
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name as keyof FormErrors]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) return;

    setStatus("submitting");

    // NOTE: This is a client-side-only placeholder submission.
    // For a live site, replace this with a form backend such as Formspree, Netlify Forms,
    // Vercel Serverless Functions, or your preferred service.
    try {
      await new Promise((resolve) => setTimeout(resolve, 1200));
      setStatus("success");
      setFormData({
        name: "",
        phone: "",
        email: "",
        service: "",
        message: "",
        preferredContact: "phone",
      });
    } catch {
      setStatus("error");
    }
  }

  return (
    <section id="contact" className="section-padding bg-white">
      <div className="container-content mx-auto">
        <div className="mx-auto max-w-3xl text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-blue-600">Contact</p>
          <h2 className="mt-2 text-3xl font-bold text-navy-900 sm:text-4xl">Get Your Free Quote</h2>
          <p className="mt-4 text-lg text-navy-700">
            Tell us about your plumbing issue and we'll get back to you quickly with next steps.
          </p>
        </div>

        <div className="mt-12 grid gap-12 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <form
              onSubmit={handleSubmit}
              className="rounded-2xl border border-gray-100 bg-white p-6 shadow-lg sm:p-8"
              noValidate
            >
              <div className="grid gap-6 sm:grid-cols-2">
                <div>
                  <label htmlFor="name" className="mb-2 block text-sm font-semibold text-navy-900">
                    Name <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className={`w-full rounded-lg border px-4 py-3 text-navy-900 outline-none transition focus:border-blue-600 focus:ring-2 focus:ring-blue-100 ${
                      errors.name ? "border-red-300" : "border-gray-200"
                    }`}
                    placeholder="Your full name"
                    autoComplete="name"
                  />
                  {errors.name && (
                    <p className="mt-1 flex items-center gap-1 text-sm text-red-600">
                      <AlertCircle className="h-4 w-4" aria-hidden="true" />
                      {errors.name}
                    </p>
                  )}
                </div>

                <div>
                  <label htmlFor="phone" className="mb-2 block text-sm font-semibold text-navy-900">
                    Phone <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    className={`w-full rounded-lg border px-4 py-3 text-navy-900 outline-none transition focus:border-blue-600 focus:ring-2 focus:ring-blue-100 ${
                      errors.phone ? "border-red-300" : "border-gray-200"
                    }`}
                    placeholder="Your phone number"
                    autoComplete="tel"
                  />
                  {errors.phone && (
                    <p className="mt-1 flex items-center gap-1 text-sm text-red-600">
                      <AlertCircle className="h-4 w-4" aria-hidden="true" />
                      {errors.phone}
                    </p>
                  )}
                </div>

                <div>
                  <label htmlFor="email" className="mb-2 block text-sm font-semibold text-navy-900">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className={`w-full rounded-lg border px-4 py-3 text-navy-900 outline-none transition focus:border-blue-600 focus:ring-2 focus:ring-blue-100 ${
                      errors.email ? "border-red-300" : "border-gray-200"
                    }`}
                    placeholder="you@example.com"
                    autoComplete="email"
                  />
                  {errors.email && (
                    <p className="mt-1 flex items-center gap-1 text-sm text-red-600">
                      <AlertCircle className="h-4 w-4" aria-hidden="true" />
                      {errors.email}
                    </p>
                  )}
                </div>

                <div>
                  <label htmlFor="service" className="mb-2 block text-sm font-semibold text-navy-900">
                    Service Required <span className="text-red-600">*</span>
                  </label>
                  <select
                    id="service"
                    name="service"
                    value={formData.service}
                    onChange={handleChange}
                    className={`w-full rounded-lg border bg-white px-4 py-3 text-navy-900 outline-none transition focus:border-blue-600 focus:ring-2 focus:ring-blue-100 ${
                      errors.service ? "border-red-300" : "border-gray-200"
                    }`}
                  >
                    <option value="">Select a service</option>
                    {services.map((service) => (
                      <option key={service} value={service}>
                        {service}
                      </option>
                    ))}
                  </select>
                  {errors.service && (
                    <p className="mt-1 flex items-center gap-1 text-sm text-red-600">
                      <AlertCircle className="h-4 w-4" aria-hidden="true" />
                      {errors.service}
                    </p>
                  )}
                </div>
              </div>

              <div className="mt-6">
                <label htmlFor="message" className="mb-2 block text-sm font-semibold text-navy-900">
                  Message <span className="text-red-600">*</span>
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={4}
                  className={`w-full rounded-lg border px-4 py-3 text-navy-900 outline-none transition focus:border-blue-600 focus:ring-2 focus:ring-blue-100 ${
                    errors.message ? "border-red-300" : "border-gray-200"
                  }`}
                  placeholder="Describe the plumbing problem and your address..."
                />
                {errors.message && (
                  <p className="mt-1 flex items-center gap-1 text-sm text-red-600">
                    <AlertCircle className="h-4 w-4" aria-hidden="true" />
                    {errors.message}
                  </p>
                )}
              </div>

              <fieldset className="mt-6">
                <legend className="mb-2 block text-sm font-semibold text-navy-900">
                  Preferred Contact Method
                </legend>
                <div className="flex flex-wrap gap-4">
                  {(["phone", "whatsapp", "email"] as const).map((method) => (
                    <label
                      key={method}
                      className="flex cursor-pointer items-center gap-2 rounded-lg border border-gray-200 px-4 py-2 transition hover:bg-gray-50 has-[:checked]:border-blue-600 has-[:checked]:bg-blue-50"
                    >
                      <input
                        type="radio"
                        name="preferredContact"
                        value={method}
                        checked={formData.preferredContact === method}
                        onChange={handleChange}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-600"
                      />
                      <span className="capitalize text-navy-900">{method}</span>
                    </label>
                  ))}
                </div>
              </fieldset>

              {status === "success" && (
                <div className="mt-6 flex items-start gap-3 rounded-lg bg-green-50 p-4 text-green-800">
                  <CheckCircle2 className="h-5 w-5 shrink-0" aria-hidden="true" />
                  <p>
                    Thank you! Your message has been received. We'll contact you shortly to discuss
                    your plumbing needs.
                  </p>
                </div>
              )}

              {status === "error" && (
                <div className="mt-6 flex items-start gap-3 rounded-lg bg-red-50 p-4 text-red-800">
                  <AlertCircle className="h-5 w-5 shrink-0" aria-hidden="true" />
                  <p>
                    Something went wrong. Please try again, or call/WhatsApp us directly for faster
                    assistance.
                  </p>
                </div>
              )}

              <button
                type="submit"
                disabled={status === "submitting"}
                className="btn-primary mt-6 w-full disabled:cursor-not-allowed disabled:opacity-60"
              >
                {status === "submitting" ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" aria-hidden="true" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Send className="h-5 w-5" aria-hidden="true" />
                    Send Message
                  </>
                )}
              </button>

              <p className="mt-4 text-center text-xs text-navy-700">
                This form is currently a demo. Connect it to a form backend to receive real
                submissions.
              </p>
            </form>
          </div>

          <aside className="space-y-6">
            <div className="rounded-2xl border border-gray-100 bg-blue-50 p-6">
              <h3 className="text-xl font-bold text-navy-900">Contact Information</h3>
              <p className="mt-2 text-navy-700">
                Reach out directly for faster service, especially for plumbing emergencies.
              </p>

              <div className="mt-6 space-y-4">
                <a
                  href={getTelLink()}
                  className="flex items-center gap-3 rounded-xl bg-white p-4 shadow-sm transition hover:shadow-md"
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-600 text-white">
                    <Phone className="h-5 w-5" aria-hidden="true" />
                  </div>
                  <div>
                    <p className="text-xs font-semibold uppercase text-navy-700">Phone</p>
                    <p className="font-semibold text-navy-900">{BUSINESS.phone}</p>
                  </div>
                </a>

                <a
                  href={getWhatsAppUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 rounded-xl bg-white p-4 shadow-sm transition hover:shadow-md"
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-whatsapp text-white">
                    <MessageCircle className="h-5 w-5" aria-hidden="true" />
                  </div>
                  <div>
                    <p className="text-xs font-semibold uppercase text-navy-700">WhatsApp</p>
                    <p className="font-semibold text-navy-900">{BUSINESS.whatsapp}</p>
                  </div>
                </a>

                <a
                  href={getMailtoLink()}
                  className="flex items-center gap-3 rounded-xl bg-white p-4 shadow-sm transition hover:shadow-md"
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-navy-900 text-white">
                    <Mail className="h-5 w-5" aria-hidden="true" />
                  </div>
                  <div>
                    <p className="text-xs font-semibold uppercase text-navy-700">Email</p>
                    <p className="font-semibold text-navy-900">{BUSINESS.email}</p>
                  </div>
                </a>
              </div>
            </div>

            <div className="rounded-2xl border border-gray-100 bg-navy-900 p-6 text-white">
              <h3 className="text-xl font-bold">Need Emergency Help?</h3>
              <p className="mt-2 text-blue-100">
                For urgent plumbing issues, calling is usually the fastest way to reach us.
              </p>
              <a href={getTelLink()} className="btn-primary mt-4 w-full bg-white text-navy-900 hover:bg-gray-100">
                Call Now
              </a>
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
}
