import { Clock, Wrench, MapPin, Star } from "lucide-react";
import { BUSINESS } from "@/config/business";

export function Trust() {
  return (
    <section className="border-y border-gray-100 bg-white">
      <div className="container-content mx-auto px-4 py-10 sm:px-6 lg:px-8">
        <p className="mb-6 text-center text-xs font-semibold uppercase tracking-wider text-navy-700">
          Editable business credentials — replace with verified information
        </p>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          <div className="flex items-start gap-4 rounded-xl bg-blue-50 p-5">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-blue-600 text-white">
              <Clock className="h-6 w-6" aria-hidden="true" />
            </div>
            <div>
              <p className="text-2xl font-bold text-navy-900">[X]+</p>
              <p className="text-sm font-medium text-navy-700">Years of Experience</p>
            </div>
          </div>

          <div className="flex items-start gap-4 rounded-xl bg-blue-50 p-5">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-blue-600 text-white">
              <Wrench className="h-6 w-6" aria-hidden="true" />
            </div>
            <div>
              <p className="text-2xl font-bold text-navy-900">[X,XXX]+</p>
              <p className="text-sm font-medium text-navy-700">Jobs Completed</p>
            </div>
          </div>

          <div className="flex items-start gap-4 rounded-xl bg-blue-50 p-5">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-blue-600 text-white">
              <MapPin className="h-6 w-6" aria-hidden="true" />
            </div>
            <div>
              <p className="text-lg font-bold text-navy-900">{BUSINESS.serviceArea}</p>
              <p className="text-sm font-medium text-navy-700">Service Area</p>
            </div>
          </div>

          <div className="flex items-start gap-4 rounded-xl bg-blue-50 p-5">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-blue-600 text-white">
              <Star className="h-6 w-6" aria-hidden="true" />
            </div>
            <div>
              <p className="text-2xl font-bold text-navy-900">[X.X/5]</p>
              <p className="text-sm font-medium text-navy-700">Customer Rating</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
