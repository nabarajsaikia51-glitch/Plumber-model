import { Phone, MessageCircle } from "lucide-react";
import { BUSINESS, getTelLink, getWhatsAppUrl } from "@/config/business";

export function BottomButtons() {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 border-t border-gray-200 bg-white p-2 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)] md:hidden">
      <div className="grid grid-cols-2 gap-2">
        <a
          href={getTelLink()}
          className="flex items-center justify-center gap-2 rounded-lg bg-blue-600 px-4 py-3 text-sm font-bold text-white active:scale-[0.98]"
          aria-label={`Call ${BUSINESS.name}`}
        >
          <Phone className="h-4 w-4" aria-hidden="true" />
          📞 Call Now
        </a>
        <a
          href={getWhatsAppUrl()}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-center gap-2 rounded-lg bg-whatsapp px-4 py-3 text-sm font-bold text-white active:scale-[0.98]"
          aria-label={`Message ${BUSINESS.name} on WhatsApp`}
        >
          <MessageCircle className="h-4 w-4" aria-hidden="true" />
          WhatsApp
        </a>
      </div>
    </div>
  );
}
