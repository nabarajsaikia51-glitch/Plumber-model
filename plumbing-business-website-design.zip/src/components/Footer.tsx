import { Droplets, Phone, MessageCircle, Mail, MapPin } from "lucide-react";
import { BUSINESS, getTelLink, getWhatsAppUrl, getMailtoLink } from "@/config/business";

const footerLinks = [
  { label: "Home", href: "#home" },
  { label: "Services", href: "#services" },
  { label: "About", href: "#about" },
  { label: "Reviews", href: "#reviews" },
  { label: "FAQ", href: "#faq" },
  { label: "Contact", href: "#contact" },
];

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-navy-900 py-12 text-white md:py-16">
      <div className="container-content mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          <div className="lg:col-span-2">
            <a href="#home" className="inline-flex items-center gap-2" aria-label="Go to homepage">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-600 text-white">
                <Droplets className="h-6 w-6" aria-hidden="true" />
              </div>
              <span className="text-lg font-bold">{BUSINESS.name}</span>
            </a>
            <p className="mt-4 max-w-md text-blue-100">
              {BUSINESS.name} provides reliable plumbing services throughout {BUSINESS.serviceArea}.
              From emergency repairs to routine maintenance, we're here to help.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a href={getTelLink()} className="btn-primary bg-white text-navy-900 hover:bg-gray-100">
                <Phone className="h-4 w-4" aria-hidden="true" />
                Call
              </a>
              <a
                href={getWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-whatsapp"
              >
                <MessageCircle className="h-4 w-4" aria-hidden="true" />
                WhatsApp
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-bold uppercase tracking-wider text-blue-200">Quick Links</h3>
            <ul className="mt-4 space-y-2">
              {footerLinks.map((link) => (
                <li key={link.href}>
                  <a href={link.href} className="text-blue-100 transition hover:text-white">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-bold uppercase tracking-wider text-blue-200">Contact</h3>
            <ul className="mt-4 space-y-3">
              <li>
                <a
                  href={getTelLink()}
                  className="flex items-center gap-2 text-blue-100 transition hover:text-white"
                >
                  <Phone className="h-4 w-4" aria-hidden="true" />
                  {BUSINESS.phone}
                </a>
              </li>
              <li>
                <a
                  href={getWhatsAppUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-blue-100 transition hover:text-white"
                >
                  <MessageCircle className="h-4 w-4" aria-hidden="true" />
                  {BUSINESS.whatsapp}
                </a>
              </li>
              <li>
                <a
                  href={getMailtoLink()}
                  className="flex items-center gap-2 text-blue-100 transition hover:text-white"
                >
                  <Mail className="h-4 w-4" aria-hidden="true" />
                  {BUSINESS.email}
                </a>
              </li>
              <li className="flex items-start gap-2 text-blue-100">
                <MapPin className="h-4 w-4 shrink-0" aria-hidden="true" />
                {BUSINESS.address}
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 border-t border-navy-700 pt-8 text-center text-sm text-blue-200">
          <p>
            &copy; {currentYear} {BUSINESS.name}. All rights reserved. | {BUSINESS.location}
          </p>
          <p className="mt-2">
            This website uses placeholder information. Replace business details before publishing.
          </p>
        </div>
      </div>
    </footer>
  );
}
