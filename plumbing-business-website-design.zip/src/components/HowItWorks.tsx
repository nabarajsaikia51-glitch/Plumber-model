import { PhoneCall, ClipboardCheck, CheckCircle } from "lucide-react";

const steps = [
  {
    number: "01",
    title: "Contact Us",
    description:
      "Call, WhatsApp, or fill out the form. Tell us about your plumbing issue and preferred way to reach you.",
    icon: PhoneCall,
  },
  {
    number: "02",
    title: "Get an Assessment & Quote",
    description:
      "We'll discuss the problem, schedule a visit if needed, and provide a clear estimate before any work begins.",
    icon: ClipboardCheck,
  },
  {
    number: "03",
    title: "Get the Problem Fixed",
    description:
      "Our plumber completes the repair or installation efficiently, cleans up, and ensures everything is working properly.",
    icon: CheckCircle,
  },
];

export function HowItWorks() {
  return (
    <section className="section-padding bg-white">
      <div className="container-content mx-auto">
        <div className="mx-auto max-w-3xl text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-blue-600">How It Works</p>
          <h2 className="mt-2 text-3xl font-bold text-navy-900 sm:text-4xl">Simple. Fast. Stress-Free.</h2>
          <p className="mt-4 text-lg text-navy-700">
            Getting your plumbing fixed shouldn't be complicated. Here's how easy it is to work with
            us.
          </p>
        </div>

        <div className="mt-12 grid gap-8 md:grid-cols-3">
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <div key={step.number} className="relative text-center">
                {index < steps.length - 1 && (
                  <div
                    className="absolute left-1/2 top-16 hidden h-0.5 w-full -translate-x-8 bg-blue-100 md:block"
                    aria-hidden="true"
                  />
                )}
                <div className="relative mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-blue-600 text-white shadow-lg">
                  <Icon className="h-8 w-8" aria-hidden="true" />
                </div>
                <div className="mt-6 inline-flex h-8 items-center justify-center rounded-full bg-blue-50 px-3 text-sm font-bold text-blue-600">
                  {step.number}
                </div>
                <h3 className="mt-4 text-xl font-bold text-navy-900">{step.title}</h3>
                <p className="mt-2 text-navy-700">{step.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
