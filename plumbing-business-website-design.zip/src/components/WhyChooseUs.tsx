import { Clock, BadgeDollarSign, ShieldCheck, MapPin, Wrench, HeartHandshake } from "lucide-react";
import { BUSINESS } from "@/config/business";

const benefits = [
  {
    title: "Fast Response",
    description:
      "We understand plumbing problems can't wait. We aim to respond promptly and schedule service at a time that works for you.",
    icon: Clock,
  },
  {
    title: "Transparent Pricing",
    description:
      "We provide clear quotes and explain the work needed before starting, so there are no surprises.",
    icon: BadgeDollarSign,
  },
  {
    title: "Professional Service",
    description:
      "Our work is completed with care, respect for your property, and attention to detail from start to finish.",
    icon: ShieldCheck,
  },
  {
    title: "Local Service",
    description:
      `Proudly serving ${BUSINESS.serviceArea} with knowledge of the local homes, weather, and plumbing systems.`,
    icon: MapPin,
  },
  {
    title: "Quality Workmanship",
    description:
      "We use reliable materials and proven techniques to deliver lasting plumbing repairs and installations.",
    icon: Wrench,
  },
  {
    title: "Customer-Focused Support",
    description:
      "Your satisfaction matters. We listen to your concerns, answer your questions, and keep you informed throughout the job.",
    icon: HeartHandshake,
  },
];

export function WhyChooseUs() {
  return (
    <section id="about" className="section-padding bg-gray-50">
      <div className="container-content mx-auto">
        <div className="mx-auto max-w-3xl text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-blue-600">Why Choose Us</p>
          <h2 className="mt-2 text-3xl font-bold text-navy-900 sm:text-4xl">
            Plumbing Service Built on Trust
          </h2>
          <p className="mt-4 text-lg text-navy-700">
            {BUSINESS.name} is committed to honest communication, dependable workmanship, and
            treating every home like our own.
          </p>
        </div>

        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {benefits.map((benefit) => {
            const Icon = benefit.icon;
            return (
              <div
                key={benefit.title}
                className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-navy-900 text-white">
                  <Icon className="h-6 w-6" aria-hidden="true" />
                </div>
                <h3 className="mt-5 text-lg font-bold text-navy-900">{benefit.title}</h3>
                <p className="mt-2 text-navy-700">{benefit.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
