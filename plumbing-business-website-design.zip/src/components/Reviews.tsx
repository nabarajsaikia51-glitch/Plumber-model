import { Star, Quote } from "lucide-react";

const reviews = [
  {
    text: "Add verified customer testimonial here.",
    author: "[Customer Name]",
    location: "[Location]",
  },
  {
    text: "Add verified customer testimonial here.",
    author: "[Customer Name]",
    location: "[Location]",
  },
  {
    text: "Add verified customer testimonial here.",
    author: "[Customer Name]",
    location: "[Location]",
  },
  {
    text: "Add verified customer testimonial here.",
    author: "[Customer Name]",
    location: "[Location]",
  },
  {
    text: "Add verified customer testimonial here.",
    author: "[Customer Name]",
    location: "[Location]",
  },
  {
    text: "Add verified customer testimonial here.",
    author: "[Customer Name]",
    location: "[Location]",
  },
];

export function Reviews() {
  return (
    <section id="reviews" className="section-padding bg-blue-50">
      <div className="container-content mx-auto">
        <div className="mx-auto max-w-3xl text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-blue-600">Reviews</p>
          <h2 className="mt-2 text-3xl font-bold text-navy-900 sm:text-4xl">What Our Customers Say</h2>
          <p className="mt-4 text-lg text-navy-700">
            These are placeholder testimonials. Replace them with real reviews from verified
            customers.
          </p>
        </div>

        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {reviews.map((review, index) => (
            <article
              key={index}
              className="relative rounded-2xl border border-gray-100 bg-white p-6 shadow-sm"
            >
              <Quote className="absolute right-5 top-5 h-8 w-8 text-blue-100" aria-hidden="true" />
              <div className="flex gap-1 text-yellow-400" aria-label="5 star rating">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-current" aria-hidden="true" />
                ))}
              </div>
              <p className="mt-4 text-navy-700 italic">&ldquo;{review.text}&rdquo;</p>
              <div className="mt-5 border-t border-gray-100 pt-4">
                <p className="font-bold text-navy-900">{review.author}</p>
                <p className="text-sm text-navy-700">{review.location}</p>
              </div>
            </article>
          ))}
        </div>

        <p className="mt-8 text-center text-sm text-navy-700">
          Reviews shown here are placeholders. Always use genuine feedback from real customers.
        </p>
      </div>
    </section>
  );
}
