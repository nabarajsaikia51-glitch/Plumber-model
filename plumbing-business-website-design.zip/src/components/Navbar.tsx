import { useState, useEffect } from "react";
import { Menu, X, Phone, Droplets } from "lucide-react";
import { BUSINESS, getTelLink } from "@/config/business";

const navLinks = [
  { label: "Home", href: "#home" },
  { label: "Services", href: "#services" },
  { label: "About", href: "#about" },
  { label: "Reviews", href: "#reviews" },
  { label: "FAQ", href: "#faq" },
  { label: "Contact", href: "#contact" },
];

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 10);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = isOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  return (
    <header
      className={`fixed left-0 right-0 top-0 z-50 transition-all duration-200 ${
        isScrolled ? "bg-white/95 shadow-md backdrop-blur" : "bg-white"
      }`}
    >
      <nav className="container-content mx-auto flex items-center justify-between px-4 py-3 lg:px-8">
        <a href="#home" className="flex items-center gap-2 focus:outline-none" aria-label="Go to homepage">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-600 text-white">
            <Droplets className="h-6 w-6" aria-hidden="true" />
          </div>
          <div className="hidden flex-col sm:flex">
            <span className="text-lg font-bold leading-tight text-navy-900">{BUSINESS.name}</span>
            <span className="text-xs font-medium text-navy-700">{BUSINESS.location}</span>
          </div>
        </a>

        {/* Desktop nav */}
        <div className="hidden items-center gap-8 lg:flex">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm font-medium text-navy-700 transition hover:text-blue-600"
            >
              {link.label}
            </a>
          ))}
        </div>

        <div className="flex items-center gap-3">
          <a
            href={getTelLink()}
            className="btn-primary hidden px-5 py-2.5 text-sm md:inline-flex"
            aria-label={`Call ${BUSINESS.name}`}
          >
            <Phone className="h-4 w-4" aria-hidden="true" />
            Call Now
          </a>

          <button
            type="button"
            onClick={() => setIsOpen(!isOpen)}
            className="inline-flex h-11 w-11 items-center justify-center rounded-lg border border-gray-200 text-navy-900 lg:hidden"
            aria-expanded={isOpen}
            aria-controls="mobile-menu"
            aria-label={isOpen ? "Close menu" : "Open menu"}
          >
            {isOpen ? <X className="h-6 w-6" aria-hidden="true" /> : <Menu className="h-6 w-6" aria-hidden="true" />}
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      {isOpen && (
        <div
          id="mobile-menu"
          className="fixed inset-x-0 top-[60px] z-40 h-[calc(100dvh-60px)] overflow-y-auto bg-white px-4 pb-24 pt-6 shadow-inner lg:hidden"
        >
          <ul className="flex flex-col gap-2">
            {navLinks.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  onClick={() => setIsOpen(false)}
                  className="block rounded-lg px-4 py-3 text-lg font-medium text-navy-900 hover:bg-blue-50"
                >
                  {link.label}
                </a>
              </li>
            ))}
            <li className="mt-4">
              <a
                href={getTelLink()}
                className="btn-primary w-full"
                onClick={() => setIsOpen(false)}
              >
                <Phone className="h-5 w-5" aria-hidden="true" />
                Call Now
              </a>
            </li>
          </ul>
        </div>
      )}
    </header>
  );
}
