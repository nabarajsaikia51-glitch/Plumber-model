import { MapPin } from "lucide-react";
import { BUSINESS } from "@/config/business";

const areas = [
  "[CITY]",
  "[AREA 1]",
  "[AREA 2]",
  "[AREA 3]",
  "[AREA 4]",
];

export function ServiceAreas() {
  return (
    <section className="section-padding bg-white">
      <div className="container-content mx-auto">
        <div className="grid items-start gap-12 lg:grid-cols-2">
          <div>
            <p className="text-sm font-semibold uppercase tracking-wider text-blue-600">Service Areas</p>
            <h2 className="mt-2 text-3xl font-bold text-navy-900 sm:text-4xl">
              Proudly Serving {BUSINESS.serviceArea}
            </h2>
            <p className="mt-4 text-lg text-navy-700">
              We provide plumbing services throughout {BUSINESS.location} and nearby communities.
              Not sure if we cover your area? Contact us and we'll let you know.
            </p>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            {areas.map((area) => (
              <div
                key={area}
                className="flex items-center gap-3 rounded-xl border border-gray-100 bg-blue-50 px-4 py-3"
              >
                <MapPin className="h-5 w-5 shrink-0 text-blue-600" aria-hidden="true" />
                <span className="font-medium text-navy-900">{area}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
