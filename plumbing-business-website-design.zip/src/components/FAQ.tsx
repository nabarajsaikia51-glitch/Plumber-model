import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { BUSINESS, getTelLink, getWhatsAppUrl } from "@/config/business";

const faqs = [
  {
    question: "Do you handle emergency plumbing?",
    answer:
      "Yes. We respond to urgent plumbing issues such as burst pipes, severe leaks, overflowing toilets, and water heater failures across our service area. Contact us by phone or WhatsApp for the fastest response.",
  },
  {
    question: "What plumbing services do you provide?",
    answer:
      "We offer a wide range of services including emergency plumbing, leak repair, pipe repair, drain cleaning, toilet repair, faucet repair, water heater service, bathroom plumbing, kitchen plumbing, and sewer/drain problem diagnosis.",
  },
  {
    question: "How quickly can you respond?",
    answer:
      "Response times depend on the time of day, your location, and current job volume. We prioritize emergencies and always aim to respond as quickly as possible. Call or WhatsApp us to check current availability.",
  },
  {
    question: "Do you provide estimates?",
    answer:
      "Yes. We provide clear estimates after understanding the scope of the work. For some jobs, we may need to visit the property to assess the issue before giving an accurate quote.",
  },
  {
    question: "What areas do you serve?",
    answer:
      `We serve ${BUSINESS.serviceArea}. If you're unsure whether we cover your location, reach out and we'll confirm.`,
  },
  {
    question: "How can I contact you?",
    answer:
      `You can call us at ${BUSINESS.phone}, message us on WhatsApp, email us at ${BUSINESS.email}, or fill out the contact form on this website.`,
  },
];

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" className="section-padding bg-gray-50">
      <div className="container-content mx-auto">
        <div className="mx-auto max-w-3xl text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-blue-600">FAQ</p>
          <h2 className="mt-2 text-3xl font-bold text-navy-900 sm:text-4xl">Frequently Asked Questions</h2>
          <p className="mt-4 text-lg text-navy-700">
            Have a question? Here are answers to some of the most common things our customers ask.
          </p>
        </div>

        <div className="mx-auto mt-12 max-w-3xl space-y-4">
          {faqs.map((faq, index) => {
            const isOpen = openIndex === index;
            return (
              <div
                key={index}
                className="overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm"
              >
                <button
                  type="button"
                  onClick={() => setOpenIndex(isOpen ? null : index)}
                  aria-expanded={isOpen}
                  aria-controls={`faq-answer-${index}`}
                  className="flex w-full items-center justify-between px-5 py-4 text-left font-semibold text-navy-900 transition hover:bg-gray-50 sm:px-6 sm:py-5"
                >
                  <span className="pr-4">{faq.question}</span>
                  <ChevronDown
                    className={`h-5 w-5 shrink-0 text-blue-600 transition-transform duration-200 ${
                      isOpen ? "rotate-180" : ""
                    }`}
                    aria-hidden="true"
                  />
                </button>
                <div
                  id={`faq-answer-${index}`}
                  className={`grid transition-all duration-200 ${
                    isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
                  }`}
                >
                  <div className="overflow-hidden">
                    <p className="px-5 pb-5 text-navy-700 sm:px-6 sm:pb-6">{faq.answer}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-12 text-center">
          <p className="text-navy-700">Still have questions?</p>
          <div className="mt-4 flex flex-col justify-center gap-3 sm:flex-row">
            <a href={getTelLink()} className="btn-primary">
              Call Us
            </a>
            <a
              href={getWhatsAppUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-whatsapp"
            >
              WhatsApp Us
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
