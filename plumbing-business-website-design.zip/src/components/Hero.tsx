import { Phone, MessageCircle, FileText, ArrowRight } from "lucide-react";
import { BUSINESS, getTelLink, getWhatsAppUrl } from "@/config/business";

export function Hero() {
  return (
    <section
      id="home"
      className="relative overflow-hidden bg-gradient-to-br from-blue-50 via-white to-white pb-16 pt-28 md:pt-36"
    >
      <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-blue-100/60 blur-3xl" aria-hidden="true" />
      <div className="absolute -bottom-32 -left-32 h-96 w-96 rounded-full bg-blue-50 blur-3xl" aria-hidden="true" />

      <div className="container-content relative mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div className="max-w-2xl">
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-blue-200 bg-white px-4 py-1.5 text-sm font-medium text-blue-700 shadow-sm">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-blue-500 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-blue-600" />
              </span>
              Serving {BUSINESS.serviceArea}
            </div>

            <h1 className="text-4xl font-extrabold leading-tight tracking-tight text-navy-900 sm:text-5xl md:text-6xl">
              Reliable Plumbing Services When You Need Them
            </h1>

            <p className="mt-6 text-lg leading-relaxed text-navy-700 sm:text-xl">
              {BUSINESS.name} provides dependable plumbing repairs and installations throughout{" "}
              {BUSINESS.serviceArea}. From emergency leaks and drain cleaning to water heaters,
              toilets, faucets, and pipe repair, we help get your plumbing back to normal.
            </p>

            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <a href={getTelLink()} className="btn-primary text-lg">
                <Phone className="h-5 w-5" aria-hidden="true" />
                Call Now
              </a>
              <a href="#contact" className="btn-outline text-lg">
                <FileText className="h-5 w-5" aria-hidden="true" />
                Get a Free Quote
              </a>
              <a
                href={getWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-whatsapp text-lg"
              >
                <MessageCircle className="h-5 w-5" aria-hidden="true" />
                WhatsApp Us
              </a>
            </div>

            <p className="mt-4 text-sm text-navy-700">
              Available for emergencies. Fast, professional service you can trust.
            </p>
          </div>

          <div className="relative mx-auto w-full max-w-lg lg:max-w-none">
            <div className="relative aspect-[4/3] overflow-hidden rounded-2xl bg-blue-100 shadow-2xl">
              <img
                src="/og-image.jpg"
                alt="Professional plumber repairing a modern kitchen faucet"
                className="h-full w-full object-cover"
                loading="eager"
                width="800"
                height="600"
              />
            </div>

            <div className="absolute -bottom-6 -left-6 hidden rounded-xl bg-white p-4 shadow-lg md:block">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-green-100 text-green-700">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-5 w-5"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                  >
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
                    <polyline points="22 4 12 14.01 9 11.01" />
                  </svg>
                </div>
                <div>
                  <p className="text-sm font-semibold text-navy-900">Trusted Local Plumbers</p>
                  <p className="text-xs text-navy-700">Serving {BUSINESS.location}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 flex justify-center lg:hidden">
          <a
            href="#services"
            className="inline-flex items-center gap-2 text-sm font-semibold text-blue-600 hover:text-blue-700"
          >
            View Our Services
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </a>
        </div>
      </div>
    </section>
  );
}
