import { Phone, MessageCircle } from "lucide-react";
import { BUSINESS, getTelLink, getWhatsAppUrl } from "@/config/business";

export function EmergencyCTA() {
  return (
    <section className="relative overflow-hidden bg-navy-900 py-16 text-white md:py-20">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg%20width%3D%2260%22%20height%3D%2260%22%20viewBox%3D%220%200%2060%2060%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Cg%20fill%3D%22none%22%20fill-rule%3D%22evenodd%22%3E%3Cg%20fill%3D%22%23ffffff%22%20fill-opacity%3D%220.03%22%3E%3Cpath%20d%3D%22M36%2034v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6%2034v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6%204V0H4v4H0v2h4v4h2V6h4V4H6z%22%2F%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E')] opacity-50" aria-hidden="true" />
      <div className="container-content relative mx-auto px-4 text-center sm:px-6 lg:px-8">
        <div className="mx-auto max-w-3xl">
          <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-red-600 shadow-lg">
            <Phone className="h-8 w-8" aria-hidden="true" />
          </div>
          <h2 className="text-3xl font-bold sm:text-4xl md:text-5xl">
            Plumbing Emergency? Call Now.
          </h2>
          <p className="mt-4 text-lg text-blue-100">
            Burst pipe? Overflowing toilet? Water leak? {BUSINESS.name} is ready to respond quickly
            across {BUSINESS.serviceArea}.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <a href={getTelLink()} className="btn-primary w-full bg-white text-navy-900 hover:bg-gray-100 sm:w-auto">
              <Phone className="h-5 w-5" aria-hidden="true" />
              Call {BUSINESS.phone}
            </a>
            <a
              href={getWhatsAppUrl(`Hello ${BUSINESS.name}, I have a plumbing emergency. My location is ______.` )}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-whatsapp w-full sm:w-auto"
            >
              <MessageCircle className="h-5 w-5" aria-hidden="true" />
              WhatsApp Emergency
            </a>
          </div>
          <p className="mt-4 text-sm text-blue-200">
            If we are unavailable, please leave a message and we will get back to you as soon as
            possible.
          </p>
        </div>
      </div>
    </section>
  );
}
