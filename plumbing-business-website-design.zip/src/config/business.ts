// Central business configuration.
// Replace the values in your Vercel dashboard environment variables or local .env file.
// All values are clearly marked as placeholders for easy replacement.

export const BUSINESS = {
  name: import.meta.env.VITE_BUSINESS_NAME || "[PLUMBER BUSINESS NAME]",
  tagline: import.meta.env.VITE_BUSINESS_TAGLINE || "Reliable Plumbing Services When You Need Them",
  description:
    import.meta.env.VITE_BUSINESS_DESCRIPTION ||
    "Professional plumbing services for homes and businesses in [CITY, STATE].",
  location: import.meta.env.VITE_BUSINESS_LOCATION || "[CITY, STATE]",
  address: import.meta.env.VITE_BUSINESS_ADDRESS || "[BUSINESS ADDRESS]",
  phone: import.meta.env.VITE_BUSINESS_PHONE || "[PHONE NUMBER]",
  whatsapp: import.meta.env.VITE_BUSINESS_WHATSAPP || "[WHATSAPP NUMBER]",
  email: import.meta.env.VITE_BUSINESS_EMAIL || "[EMAIL]",
  websiteUrl: import.meta.env.VITE_WEBSITE_URL || "https://your-domain.vercel.app",
  serviceArea: import.meta.env.VITE_BUSINESS_SERVICE_AREA || "[CITY + SURROUNDING AREAS]",
  // Use "true" to display placeholder stats while you populate real values.
  showPlaceholderStats: import.meta.env.VITE_SHOW_PLACEHOLDER_STATS === "true",
} as const;

export type BusinessConfig = typeof BUSINESS;

// Helper to generate a WhatsApp URL with a pre-filled message.
export function getWhatsAppUrl(message?: string): string {
  const rawNumber = BUSINESS.whatsapp.replace(/\D/g, "");
  const text = encodeURIComponent(
    message ||
      `Hello ${BUSINESS.name}, I need plumbing service. My location is ______ and the problem is ______.`
  );
  return `https://wa.me/${rawNumber}?text=${text}`;
}

// Helper to generate a tel: link.
export function getTelLink(): string {
  return `tel:${BUSINESS.phone.replace(/\D/g, "")}`;
}

// Helper to generate a mailto: link.
export function getMailtoLink(subject?: string): string {
  const encodedSubject = encodeURIComponent(subject || `Service Inquiry - ${BUSINESS.name}`);
  return `mailto:${BUSINESS.email}?subject=${encodedSubject}`;
}
