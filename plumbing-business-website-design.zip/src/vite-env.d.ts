/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_BUSINESS_NAME: string;
  readonly VITE_BUSINESS_TAGLINE: string;
  readonly VITE_BUSINESS_DESCRIPTION: string;
  readonly VITE_BUSINESS_LOCATION: string;
  readonly VITE_BUSINESS_ADDRESS: string;
  readonly VITE_BUSINESS_PHONE: string;
  readonly VITE_BUSINESS_WHATSAPP: string;
  readonly VITE_BUSINESS_EMAIL: string;
  readonly VITE_WEBSITE_URL: string;
  readonly VITE_BUSINESS_SERVICE_AREA: string;
  readonly VITE_SHOW_PLACEHOLDER_STATS: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
