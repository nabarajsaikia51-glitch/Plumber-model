import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { Trust } from "@/components/Trust";
import { Services } from "@/components/Services";
import { EmergencyCTA } from "@/components/EmergencyCTA";
import { WhyChooseUs } from "@/components/WhyChooseUs";
import { HowItWorks } from "@/components/HowItWorks";
import { Reviews } from "@/components/Reviews";
import { ServiceAreas } from "@/components/ServiceAreas";
import { FAQ } from "@/components/FAQ";
import { Contact } from "@/components/Contact";
import { Footer } from "@/components/Footer";
import { BottomButtons } from "@/components/BottomButtons";
import { SchemaOrg } from "@/components/SchemaOrg";

export default function App() {
  return (
    <>
      <SchemaOrg />
      <a
        href="#main-content"
        className="fixed left-4 top-4 z-[60] -translate-y-20 rounded-lg bg-navy-900 px-4 py-2 text-sm font-semibold text-white transition focus:translate-y-0"
      >
        Skip to main content
      </a>
      <Navbar />
      <main id="main-content" className="pb-20 md:pb-0">
        <Hero />
        <Trust />
        <Services />
        <EmergencyCTA />
        <WhyChooseUs />
        <HowItWorks />
        <Reviews />
        <ServiceAreas />
        <FAQ />
        <Contact />
      </main>
      <Footer />
      <BottomButtons />
    </>
  );
}
